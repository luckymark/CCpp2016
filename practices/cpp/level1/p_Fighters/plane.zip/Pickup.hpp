//
//  Pickup.hpp
//  plane
//
//  Created by mac on 16/5/10.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef Pickup_hpp
#define Pickup_hpp
#include "SecondaryObject.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <stdio.h>
class Pickup : public SecondaryObject {
  public:
    virtual void use() = 0;
};
#endif /* Pickup_hpp */
