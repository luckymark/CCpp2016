//
//  Bullet.cpp
//  plane
//
//  Created by mac on 16/5/1.
//  Copyright © 2016年 CCPP. All rights reserved.
//
#include "Bullet.hpp"
Bullet::~Bullet() {}