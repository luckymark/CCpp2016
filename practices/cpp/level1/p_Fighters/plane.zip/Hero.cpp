//
//  Hero.cpp
//  plane
//
//  Created by mac on 16/5/1.
//  Copyright © 2016年 CCPP. All rights reserved.
//
#include "Hero.hpp"
#include "HeroBullet.hpp"
#include "Stage.hpp"
#include "Texture.hpp"
bool Hero::isDead() { return (life <= 0); };
Hero::Hero() {
    deviation.x = 100;
    deviation.y = 100;
    radius = 30;
    setTexture(Texture::HERO);
    blood.setPosition(20.0, 20.0);
};
void Hero::healthUp() { life = std::min(life + 1, 4); }
void Hero::luckUp() { luck = std::min(luck + 1, 5); }
int Hero::getLuck() { return luck; }
void Hero::draw(sf::RenderWindow &window) {
    blood.setTexture(Texture::BLOOD[life - 1]);
    double time = clock.getElapsedTime().asSeconds();
    if (blooding) {
        if (time < 1) {
            setColor(sf::Color(255 - 50 * time, 255 - 200 * time,
                               255 - 200 * time, 255));
        }
        if (time >= 1 && time < 2) {
            setColor(sf::Color(155 + 50 * time, 200 * time - 145,
                               200 * time - 145, 255));
        }
        if (time >= 2) {
            setColor(sf::Color(255, 255, 255, 255));
        }
    } else {
        setColor(sf::Color(255, 255, 255, 255));
    }
    window.draw(blood);
    Score::getInstance()->draw(window);
    window.draw(*this);
}
void Hero::hit() {
    if (blooding && clock.getElapsedTime().asSeconds() < 2) {
        return;
    }
    blooding = true;
    life--;
    clock.restart();
}
void Hero::initial() {
    damage = 1;
    luck = 0;
    life = 4;
    speed = 5.0;
    blooding = false;
    memset(direction, 0, sizeof(direction));
    gun.autoFire = 0;
    setColor(sf::Color(255, 255, 255, 255));
}
void Hero::damageUp() { damage = std::min(4.0, damage + 0.3); }
double Hero::getDamage() { return damage; }
void Hero::speedUp() { speed = std::min(speed + 0.5, 10.0); }
void Hero::move() {
    for (int i = 0; i < 4; ++i) {
        if (!direction[i])
            continue;
        switch (i) {
        case UP:
            if (getPosition().y >= -50)
                sf::Sprite::move(0, -speed);
            break;
        case DOWN:
            if (getPosition().y <= 1050)
                sf::Sprite::move(0, speed);
            break;
        case LEFT:
            if (getPosition().x >= -50)
                sf::Sprite::move(-speed, 0);
            break;
        case RIGHT:
            if (getPosition().x <= 1770)
                sf::Sprite::move(speed, 0);
            break;
        default:
            break;
        }
    }
}
void Hero::fire() {
    sf::Time elapsed = gun.clock.getElapsedTime();
    if ((!gun.autoFire) || (elapsed.asSeconds() <= 0.5 && gun.hasFire)) {
        return;
    }
    if (elapsed.asSeconds() > 0.5) {
        gun.clock.restart();
    }
    Stage::getInstance()->creatBullet(
        new HeroBullet(getPosition().x + 65, getPosition().y + 50));
    gun.hasFire = true;
}
void Hero::run(sf::RenderWindow &window) {
    sf::Event event;
    while (window.pollEvent(event)) {
        switch (event.type) {
        case sf::Event::KeyPressed:
            switch (event.key.code) {
            case sf::Keyboard::Up:
                direction[UP] = true;
                break;
            case sf::Keyboard::Down:
                direction[DOWN] = true;
                break;
            case sf::Keyboard::Left:
                direction[LEFT] = true;
                break;
            case sf::Keyboard::Right:
                direction[RIGHT] = true;
                break;
            case sf::Keyboard::Space:
                gun.autoFire = true;
                break;
            case sf::Keyboard::Escape:
                window.close();
                break;
            default:
                break;
            }
            break;
        case sf::Event::KeyReleased:
            switch (event.key.code) {
            case sf::Keyboard::Up:
                direction[UP] = false;
                break;
            case sf::Keyboard::Down:
                direction[DOWN] = false;
                break;
            case sf::Keyboard::Left:
                direction[LEFT] = false;
                break;
            case sf::Keyboard::Right:
                direction[RIGHT] = false;
                break;
            case sf::Keyboard::Space:
                gun.autoFire = false;
            default:
                break;
            }
            break;
        default:
            break;
        }
    }
    Hero::move();
    Hero::fire();
}
