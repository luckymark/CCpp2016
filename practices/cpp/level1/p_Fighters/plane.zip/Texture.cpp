//
//  Texture.cpp
//  Fighters
//
//  Created by luckymark on 13-10-28.
//  Copyright (c) 2013年 luckymark. All rights reserved.
//

#include "Texture.hpp"
//#define resourcePath() (std::string)("")
#include <cstring>
#define PICKUP_NUMBER 4
sf::Texture Texture::HERO;
sf::Texture Texture::ENEMY_1;
sf::Texture Texture::ENEMY_2;
sf::Texture Texture::ENEMY_3;
sf::Texture Texture::ENEMY_4;
sf::Texture Texture::ENEMY_5;
sf::Texture Texture::BULLET;
sf::Texture Texture::ENEMY_BULLET;
sf::Texture Texture::MAIN_MENU_BACK_GROUND;
sf::Texture Texture::BLOOD[4];
sf::Texture Texture::STAGE_BACK_GROUND;
sf::Texture Texture::HELP_BACK_GROUND;
sf::Texture Texture::VICTORY_BACK_GROUND;
sf::Texture Texture::PICKUP[PICKUP_NUMBER];
void Texture::load() {
    for(int i=0;i<PICKUP_NUMBER;++i){
        PICKUP[i].loadFromFile(resourcePath()+"补给"+std::to_string(i)+".png");
    }
    for (int i = 0; i < 4; ++i) {
        BLOOD[i].loadFromFile(resourcePath() + "血量剩余" +
                              std::to_string(i + 1) + ".png");
    }
    HELP_BACK_GROUND.loadFromFile(resourcePath() + "帮助.png");
    MAIN_MENU_BACK_GROUND.loadFromFile(resourcePath() + "背景.jpg");
    STAGE_BACK_GROUND.loadFromFile(resourcePath() + "关卡1.png");
    HERO.loadFromFile(resourcePath() + "飞机.psd");
    ENEMY_1.loadFromFile(resourcePath() + "棒球.png");
    ENEMY_3.loadFromFile(resourcePath() + "篮球.png");
    ENEMY_2.loadFromFile(resourcePath() + "网球.png");
    ENEMY_4.loadFromFile(resourcePath() + "足球.png");
    BULLET.loadFromFile(resourcePath() + "子弹.psd");
    ENEMY_5.loadFromFile(resourcePath() + "桌球.png");
    ENEMY_BULLET.loadFromFile(resourcePath() + "敌人子弹.psd");
    VICTORY_BACK_GROUND.loadFromFile(resourcePath()+"胜利背景.jpg");
}