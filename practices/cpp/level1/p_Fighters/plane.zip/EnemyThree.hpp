//
//  EnemyThree.hpp
//  plane
//
//  Created by mac on 16/5/7.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef EnemyThree_hpp
#define EnemyThree_hpp
#include "Bullet.hpp"
#include "Enemy.hpp"
#include "Texture.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <stdio.h>
class EnemyThree : public Enemy {
  public:
    EnemyThree(int position) {
        life=4.0;
        point = 10;
        setTexture(Texture::ENEMY_3);
        setPosition(1800, position);
        deviation.x = 50;
        deviation.y = 50;
        radius = 50;
        initialVelocity = 2.5;
        acceleration = 0;
        unitVector.x = -1;
        unitVector.y = 0;
    };
    void fire();
};
#endif /* EnemyThree_hpp */
