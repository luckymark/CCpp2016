#include "EnemyFactory.hpp"
#include "HealthUp.hpp"
#include "Hero.hpp"
#include "PickupFactory.hpp"
#include "Stage.hpp"
#include <cmath>
#define STAGE 1
#define VICTORY 98
#define MAIN_MENU 0
#define HELP 99

void Stage::initial() {
    setPosition(0, 0);
    clock.restart();
    coolDown.restart();
    for (auto &i : allEnemy) {
        delete i;
        i = NULL;
    }
    for (auto &i : allBullet) {
        delete i;
        i = NULL;
    }
    for (auto &i : allPickup) {
        delete i;
        i = NULL;
    }
    allBullet.clear();
    allEnemy.clear();
    allPickup.clear();
}
int Stage::run() {
    if (clock.getElapsedTime().asSeconds() > 65) {
        stage++;
        return VICTORY;
    }
    if (coolDown.getElapsedTime().asSeconds() > 3 - 0.3*stage &&
        clock.getElapsedTime().asSeconds() <= 60) {
        coolDown.restart();
        Enemy *enemy = EnemyFactory::createEnemy(stage + rand() % 2);
        creatEnemy(enemy);
    }
    for (auto &i : allBullet) {
        i->move();
    }
    for (auto &i : allEnemy) {
        i->move();
    }
    for (auto &i : allPickup) {
        i->move();
    }
    for (auto i = allBullet.begin(); i != allBullet.end();) {
        auto &I = *i;
        if (I->out()) {
            delete I;
            I = NULL;
            i = allBullet.erase(i);
        } else {
            i++;
        }
    }
    for (auto i = allEnemy.begin(); i != allEnemy.end();) {
        auto &I = *i;
        if (I->out()) {
            delete I;
            I = NULL;
            i = allEnemy.erase(i);
        } else {
            i++;
        }
    }
    for (auto i = allPickup.begin(); i != allPickup.end();) {
        auto &I = *i;
        if (I->out()) {
            delete I;
            I = NULL;
            i = allPickup.erase(i);
        } else {
            i++;
        }
    }
    for (auto &i : allEnemy) {
        i->fire();
    }
    return STAGE;
}
void Stage::draw(sf::RenderWindow &window) {
    move(-0.5, 0);
    window.draw(*this);
    for (auto &i : allPickup) {
        window.draw(*i);
    }
    for (auto &i : allBullet) {
        window.draw(*i);
    }
    for (auto &i : allEnemy) {
        window.draw(*i);
    }
}
void Stage::creatEnemy(Enemy *enemy) { allEnemy.push_back(enemy); }
void Stage::creatBullet(Bullet *bullet) { allBullet.push_back(bullet); }
void Stage::creatPickup(Pickup *pickup) {
    if (pickup == NULL) {
        return;
    }
    allPickup.push_back(pickup);
}
int Stage::collision() {
    for (auto i = allBullet.begin(); i != allBullet.end();) {
        auto &I = *i;
        if (I->isHero) {
            auto j = allEnemy.begin();
            for (; j != allEnemy.end();) {
                auto &J = *j;
                if (touch(J, I)) {
                    J->hit();
                    if (J->isDead()) {
                        creatPickup(PickupFactory::createPickup(
                            rand() % (14 + stage / 2 -
                                      Hero::getInstance()->getLuck()),
                            J->getPosition().x + 10, J->getPosition().y + 10));
                        Score::getInstance()->getScore(J->point);
                        delete J;
                        J = NULL;
                        j = allEnemy.erase(j);
                    }
                    delete I;
                    I = NULL;
                    i = allBullet.erase(i);
                    break;
                } else {
                    j++;
                }
            }
            if (j == allEnemy.end()) {
                i++;
            }
        } else {
            if (touch(Hero::getInstance(), I)) {
                Hero::getInstance()->hit();
                if (Hero::getInstance()->isDead()) {
                    return MAIN_MENU;
                }
                delete I;
                I = NULL;
                i = allBullet.erase(i);
            } else {
                i++;
            }
        }
    }
    for (auto &i : allEnemy) {
        if (touch(i, Hero::getInstance())) {
            Hero::getInstance()->hit();
            if (Hero::getInstance()->isDead()) {
                return MAIN_MENU;
            }
        }
    }
    for (auto i = allPickup.begin(); i != allPickup.end();) {
        auto &I = *i;
        if (touch(I, Hero::getInstance())) {
            I->use();
            delete I;
            I = NULL;
            i = allPickup.erase(i);
        } else {
            i++;
        }
    }
    return STAGE;
}