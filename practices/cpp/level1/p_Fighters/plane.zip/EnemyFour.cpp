//
//  EnemyFour.cpp
//  plane
//
//  Created by mac on 16/5/9.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#include "EnemyFour.hpp"
void EnemyFour::fire() {}