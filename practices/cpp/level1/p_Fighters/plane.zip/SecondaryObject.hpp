//
//  SecondaryObject.hpp
//  plane
//
//  Created by mac on 16/5/7.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef SecondaryObject_hpp
#define SecondaryObject_hpp
#include "Object.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <stdio.h>
#include <stdio.h>
class SecondaryObject : public Object {
  public:
    void move();
    bool out();
  protected:
    double initialVelocity;
    double acceleration = 0;
    sf::Vector2f unitVector;
    sf::Clock occurrenceTime;
    Object *target = NULL;
};
#endif /* SecondaryObject_hpp */
