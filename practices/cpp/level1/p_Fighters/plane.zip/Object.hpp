//
//  Object.hpp
//  plane
//
//  Created by mac on 16/5/7.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef Object_hpp
#define Object_hpp
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
class Object : public sf::Sprite {
  protected:
    sf::Vector2i deviation;

  public:
    int radius;
    friend sf::Vector2f getUnitVector(Object *source, Object *target);
    friend bool touch(Object *first, Object *second);
};
#endif /* Object_hpp */
