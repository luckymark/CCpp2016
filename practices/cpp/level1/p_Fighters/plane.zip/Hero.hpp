//
//  Hero.hpp
//  plane
//
//  Created by mac on 16/5/1.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef Hero_hpp
#define Hero_hpp
#include "Bullet.hpp"
#include "Gun.hpp"
#include "Object.hpp"
#include "Score.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <cstring>
#include <iostream>
#include <stdio.h>
#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3
class Hero : public Object {
  private:
    Hero();
    void fire();
    void move();
    bool direction[4];
    Sprite blood;
    bool blooding = 0;
    sf::Clock clock;
    Gun gun;
    double speed;
    int life;
    int luck;
    double damage;
  public:
    double getDamage();
    void damageUp();
    bool isDead();
    void hit();
    void healthUp();
    void luckUp();
    void speedUp();
    int getLuck();
    void initial();
    static Hero *getInstance() {
        static Hero *singleton;
        if (singleton == NULL) {
            singleton = new Hero();
        }
        return singleton;
    }
    void run(sf::RenderWindow &window);
    void draw(sf::RenderWindow &window);
};
#endif /* Hero_hpp */
