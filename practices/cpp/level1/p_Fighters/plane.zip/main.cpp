#include "Game.hpp"
#include "Texture.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <ctime>
int main(int, char const **) {
    srand(time(NULL));
    Texture::load();
    sf::RenderWindow window(sf::VideoMode(1920, 1200), L"打飞机"
                            ,sf::Style::None);
    window.setFramerateLimit(65);
    Game *game = Game::getInstance();
    game->run(window);
    return EXIT_SUCCESS;
}
