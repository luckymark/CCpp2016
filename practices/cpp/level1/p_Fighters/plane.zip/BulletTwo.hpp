#ifndef BulletTwo_hpp
#define BulletTwo_hpp

#include "Bullet.hpp"
#include "Hero.hpp"
#include "Texture.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <stdio.h>
class BulletTwo : public Bullet {
  public:
    BulletTwo(double positionX, double positionY, Object *target=Hero::getInstance()) {
        initialVelocity = 10.0;
        acceleration = 0;
        setPosition(positionX, positionY);
        deviation.x = 50;
        deviation.y = 50;
        radius = 25;
        unitVector = getUnitVector(this, target);
        setTexture(Texture::ENEMY_BULLET);
        isHero = false;
    };
};
#endif /* BulletTwo_hpp */
