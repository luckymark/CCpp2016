//
//  EnemySix.hpp
//  plane
//
//  Created by mac on 16/5/12.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef EnemySix_hpp
#define EnemySix_hpp
#include "Enemy.hpp"
#include "Texture.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <stdio.h>
class EnemySix : public Enemy {
public:
    EnemySix(int position) {
        point = 15;
        life = 8;
        setTexture(Texture::ENEMY_3);
        setPosition(1800, position);
        deviation.x = 50;
        deviation.y = 50;
        radius = 50;
        initialVelocity = 3.0;
        acceleration = 0;
        unitVector.x = -1;
        unitVector.y = 0;
    };
    bool isDead();
    void fire();
};
#endif /* EnemySix_hpp */
