//
//  SecondaryObject.cpp
//  plane
//
//  Created by mac on 16/5/7.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#include "SecondaryObject.hpp"
#include <cmath>
void SecondaryObject::move() {
    if (target != NULL) {
        unitVector = getUnitVector(this, target);
    }
    Object::move((initialVelocity +
                  occurrenceTime.getElapsedTime().asSeconds() * acceleration) *
                     unitVector.x,
                 (initialVelocity +
                  occurrenceTime.getElapsedTime().asSeconds() * acceleration) *
                     unitVector.y);
}
bool SecondaryObject::out() {
    return (getPosition().x >= 1800 + 2 * radius ||
            getPosition().x < -2 * radius || getPosition().y < -2 * radius ||
            getPosition().y >= 1200 + radius);
}