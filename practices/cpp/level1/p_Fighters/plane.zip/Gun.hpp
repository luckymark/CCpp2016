//
//  Gun.hpp
//  plane
//
//  Created by mac on 16/5/2.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef Gun_hpp
#define Gun_hpp
#include "Bullet.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <stdio.h>
#include <vector>
class Gun {
  public:
    bool autoFire;
    sf::Clock clock;
    bool hasFire;
};
#endif /* Gun_hpp */
