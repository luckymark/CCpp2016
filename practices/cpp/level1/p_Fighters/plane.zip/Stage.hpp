//
//  Stage.hpp
//  plane
//
//  Created by mac on 16/5/1.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#ifndef Stage_hpp
#define Stage_hpp
#include "Bullet.hpp"
#include "Enemy.hpp"
#include "EnemyOne.hpp"
#include "Pickup.hpp"
#include "Texture.hpp"
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <list>
#include <stdio.h>
class Stage : public sf::Sprite {
  private:
    Stage() { setTexture(Texture::STAGE_BACK_GROUND); }
    std::list<Bullet *> allBullet;
    std::list<Enemy *> allEnemy;
    std::list<Pickup *> allPickup;
    sf::Clock clock;
    sf::Clock coolDown;

  public:
    static Stage *getInstance() {
        static Stage *singleton;
        if (singleton == NULL) {
            singleton = new Stage();
        }
        return singleton;
    }
    int stage = 0;
    void initial();
    int run();
    int collision();
    void draw(sf::RenderWindow &window);
    void creatBullet(Bullet *bullet);
    void creatEnemy(Enemy *enemy);
    void creatPickup(Pickup *pickup);
};
#endif /* Stage_hpp */
