//
//  PickupFactory.cpp
//  plane
//
//  Created by mac on 16/5/10.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#include "HealthUp.hpp"
#include "LuckUp.hpp"
#include "DamageUp.hpp"
#include "speedUp.hpp"
#include "PickupFactory.hpp"
Pickup *PickupFactory::createPickup(int type, double PositionX,
                                    double PositionY) {
    switch (type) {
    case 0:
        return new HealthUp(PositionX, PositionY);
    case 1:
        return new DamageUp(PositionX, PositionY);
    case 2:
        return new SpeedUp(PositionX, PositionY);
    case 3:
        return new LuckUp(PositionX, PositionY);
    default:
        return NULL;
    }
}