//
//  EnemyOne.cpp
//  plane
//
//  Created by mac on 16/5/2.
//  Copyright © 2016年 CCPP. All rights reserved.
//

#include "EnemyOne.hpp"
void EnemyOne::fire() {}