#include "Enemy.hpp"
#include "Hero.hpp"
bool Enemy::isDead() { return (life <= 1e-6); };
void Enemy::hit() { life-=Hero::getInstance()->getDamage(); }