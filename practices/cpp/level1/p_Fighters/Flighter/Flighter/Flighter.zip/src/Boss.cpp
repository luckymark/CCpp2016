#include "Boss.hpp"

Boss::Boss(int m_rand) :Flying(m_rand % 434 + 83, -124, 0, 0.002, 83, 124, 83)
{
	times = 20;
	setAcceleration(-0.0005);
}

Boss::~Boss()
{
}
