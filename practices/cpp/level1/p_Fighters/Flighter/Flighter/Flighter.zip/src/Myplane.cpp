#include "Myplane.hpp"

Myplane::Myplane():Flying(315,770,0,0,49,62,49)
{
	setScale(sf::Vector2f(.5f, .5f));
	setColor(sf::Color(0, 200, 100, 255));
	movespeed = 0.006;
	times = 5;
	life = 3;
}

Myplane::~Myplane()
{
}

void Myplane::moveMe()
{
	this->setPosition(getX(), getY());
}

float Myplane::getSpeed()
{
	return movespeed;
}
