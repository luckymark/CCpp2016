#include "Bossshoot.hpp"

Bossshoot::Bossshoot(float x, float y, float speedx, float speedy):Flying(x,y,speedx,speedy,5,5,5)
{
}

Bossshoot::~Bossshoot()
{
}
