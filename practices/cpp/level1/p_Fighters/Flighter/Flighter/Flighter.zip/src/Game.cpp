#include"Game.hpp"
#include<time.h>

Game::Game()
	:background1(-2400),
	background2(-5500),
	type("PLAY!")
{
	srand(time(0));
	timeNow = sf::seconds(0.00f);
	type.setPosition(270, 350);
	for (size_t i = 0; i < 100; i++)
	{
		myshoot[i] = NULL;
	}
	for (size_t i = 0; i < 20; i++)
	{
		enemy[i] = NULL;
	}
	for (size_t i = 0; i < 100; i++)
	{
		enemyshoot[i] = NULL;
	}
	for (size_t i = 0; i < 5; i++)
	{
		boss[i] = NULL;
	}

}

void Game::play()
{
	record_time();
	loop();
}

void Game::record_time()
{
	static sf::Clock clock;
	if (clock.getElapsedTime() - timeNow >= sf::seconds(0.01f))
	{
		if (clock.getElapsedTime()-timeNow>=sf::seconds(0.02f))
		{
			timeNow = clock.getElapsedTime();
		}
		else
		{
		timeNow += sf::seconds(0.01f);
		}
		ifRefrash = true;
	}
	else
	{
		ifRefrash = false;
	}
}

void Game::loop()
{
	sf::RenderWindow window(sf::VideoMode(600, 800), "My window");

	window.setFramerateLimit(400);
	
	while (window.isOpen())
	{

		giveTexture();
		record_time();
		sf::Event event;
		while(window.pollEvent(event));
		{
			if (event.type == sf::Event::Closed)
			{
				window.close();
			}

			if (event.type == sf::Event::LostFocus)
			{
			}
		}

		mouseManager(window);//mouse if pressed

		keyboardManager(window);//keyboard if pressed

		if (ifRefrash)
		{
			if (type.getifConceled())//create enemies autoly
			{
				createenemy();
				shootall();
			}

			window.clear();

			drawall(window);

			window.display();
		}
		
	}
}

void Game::drawall(sf::RenderWindow &window)
{
	background1.move();//background1
	background1.ifBottom();
	window.draw(background1);

	background2.move();//background2
	background2.ifBottom();
	window.draw(background2);

	if (!type.getifConceled())
	{
		window.draw(type);//menu
	}
	else
	{
		myplane.moveMe();//myplane
		window.draw(myplane);

		for (size_t i = 0; i < 100; i++)
		{
			if (enemyshoot[i] != NULL)
			{
				enemyshoot[i]->move();
				window.draw(*enemyshoot[i]);
			}
		}

		for (size_t i = 0; i < 20; i++)
		{
			if (enemy[i] != NULL)
			{
				enemy[i]->move();
				window.draw(*enemy[i]);
			}
		}
	}
	
}

void Game::collision()
{
	
}

void Game::giveTexture()
{
	background1.setTexture(load.background);
	background2.setTexture(load.background);
	type.setFont(load.font);
	myplane.setTexture(load.myplane);
	for (size_t i = 0; i < 20; i++)
	{
		if (enemy[i] != NULL)
		{
			enemy[i]->setTexture(load.enemy);
		}
	}
	for (size_t i = 0; i < 100; i++)
	{
		if (enemyshoot[i] != NULL)
		{
			enemyshoot[i]->setTexture(load.enemyshoot);
		}
	}
}

void Game::keyboardManager(sf::Window &window)
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	{
		if(myplane.getX()>25)
			myplane.setX(myplane.getX() - myplane.getSpeed());
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		if(myplane.getX()<575)
			myplane.setX(myplane.getX() + myplane.getSpeed());
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	{
		if(myplane.getY()>35)
			myplane.setY(myplane.getY() - myplane.getSpeed());
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
		if(myplane.getY()<770)
			myplane.setY(myplane.getY() + myplane.getSpeed());
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
	{
		//shoots
	}
}

void Game::mouseManager(sf::Window &window)
{
	if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
	{
		sf::Vector2i localPosition = sf::Mouse::getPosition(window);
		if (type.getifConceled() == 0 && localPosition.x < 350 && localPosition.x > 250 && localPosition.y < 400 && localPosition.y > 340)
		{
			type.setifConceled(1);
		}
	}
	
	
}

void Game::createenemy()
{
	sf::Time iftime = sf::seconds(5);
	sf::Time maxvalue = sf::seconds(0.01);
	if (timeNow % iftime < maxvalue)
	{
		int i = create<Enemy>(enemy, 20);
	}
	
	iftime = sf::seconds(40);
	if (timeNow % iftime == sf::Time::Zero)
	{
		int i = create<Boss>(boss, 5);
	}
}

void Game::shootall()
{
	for (size_t i = 0; i < 20; i++)
	{
		if (enemy[i] != NULL)
		{
			enemy[i]->shoot(enemyshoot, 100, myplane.getX(), myplane.getY());
		}
	}
}

