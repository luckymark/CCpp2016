#include "Myshoot.hpp"

Myshoot::Myshoot(float x, float y) :Flying(x, y, 0, .5, 5, 5, 5)
{
}

Myshoot::~Myshoot()
{
}
