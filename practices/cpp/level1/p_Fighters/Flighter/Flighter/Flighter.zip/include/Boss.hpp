#pragma once

#include"Flying.hpp"

class Boss:public Flying
{
public:
	Boss(int m_rand);
	~Boss();
	int times;

private:

};
