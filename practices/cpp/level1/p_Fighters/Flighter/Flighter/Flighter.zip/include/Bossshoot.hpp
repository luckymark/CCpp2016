#pragma once

#include"Flying.hpp"

class Bossshoot :public Flying
{
public:
	Bossshoot(float x,float y,float speedx,float speedy);
	~Bossshoot();
	
private:

};
