#pragma once

#include"Flying.hpp"

class Myplane:public Flying
{
public:
	Myplane();
	~Myplane();
	void moveMe();
	float getSpeed();
	int times;
	int life;
private:
	float movespeed;
};
