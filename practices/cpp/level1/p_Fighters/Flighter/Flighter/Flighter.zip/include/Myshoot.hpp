#pragma once

#include"Flying.hpp"

class Myshoot:public Flying
{
public:
	Myshoot(float x,float y);
	~Myshoot();

private:

};
