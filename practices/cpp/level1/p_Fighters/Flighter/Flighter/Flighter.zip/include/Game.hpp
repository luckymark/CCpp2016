#pragma once

#include<string>
#include<iostream>
#include<ctime>
#include<SFML/Window.hpp>
#include<SFML/Graphics.hpp>
#include<SFML/Window.hpp>
#include"Background.hpp"
#include"Type.hpp"
#include"Load.hpp"
#include"Myplane.hpp"
#include"Enemy.hpp"
#include"Boss.hpp"
#include"Enemyshoot.hpp"
#include"Myshoot.hpp"

class Game
{
public:
	Game();
	void play();
	void record_time();
	void loop();
	void drawall(sf::RenderWindow &window);
	void collision();
	void giveTexture();
	void keyboardManager(sf::Window &window);
	void mouseManager(sf::Window &window);
	template <typename T>
	int create(T *t[], int i);
	void createenemy();
	void shootall();
	
private:
	Load load;
	bool ifRefrash = false;
	sf::Time timeNow;
	Background background1;
	Background background2;
	Type type;
	Myplane myplane;
	Myshoot *myshoot[100];
	Enemy *enemy[20];
	Enemyshoot *enemyshoot[100];
	Boss *boss[5];

};

template<typename T>
int Game::create(T *t[], int i)
{
	int m_rand = rand();
	for (int j = 0; j < i; j++)
	{
		if (t[j] == NULL)
		{
			t[j]=new T(m_rand);
			return j;
		}
	}
}
